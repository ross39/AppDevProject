﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace TodoList
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        

       
        public MainPage()
        {
            this.InitializeComponent();
            this.NavigationCacheMode = NavigationCacheMode.Enabled;
        }


        protected override void OnNavigatedTo(NavigationEventArgs e)
        {

            ApplicationDataContainer localSettings = ApplicationData.Current.LocalSettings;

            // read the setting for the colour
            try
            {
                string colourName = localSettings.Values["screenColour"].ToString();
                switch (colourName)
                {
                    case "Green":
                        this.Background = new SolidColorBrush(Colors.Green);
                        break;
                    default:
                        break;
                }
            }
            catch (Exception)
            {

            }


            base.OnNavigatedTo(e);
        }

        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            StackPanel sp = new StackPanel(); ;
            TextBox textbox = new TextBox();
            textbox.Text += Input.Text;
            textbox.IsReadOnly = true;
            CheckBox done = new CheckBox();
            done.Content = "check when done";
            done.Checked += Done_Checked;

            sp.Orientation = Orientation.Horizontal;
            sp.Children.Add(textbox);
            sp.Children.Add(done);



            outputArea.Children.Add(sp);
            
        }

        private void Done_Checked(object sender, RoutedEventArgs e)
        {
            // find the parent horiz sp, and move it.
            TextBox textbox = new TextBox();
            textbox.Text += textbox.Text;
            textbox.IsReadOnly = true;
            StackPanel stackpanel = new StackPanel();

            stackpanel.Orientation = Orientation.Horizontal;

            stackpanel.Children.Add(textbox);
           
        }

        private void ButtonSettings_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Settings));
        }

        private void Output_TextChanged(object sender, TextChangedEventArgs e)
        {
           
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ButtonClear_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
